using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace ClientApp.Pages.Account
{
    public class LoginModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
