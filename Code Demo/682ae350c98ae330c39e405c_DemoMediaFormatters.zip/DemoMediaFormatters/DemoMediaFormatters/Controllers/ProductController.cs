﻿using DemoMediaFormatters.Models;
using Microsoft.AspNetCore.Mvc;
using HttpGetAttribute = Microsoft.AspNetCore.Mvc.HttpGetAttribute;
using RouteAttribute = Microsoft.AspNetCore.Mvc.RouteAttribute;
namespace DemoMediaFormatters.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    
    //[Consumes("application/json")]

    public class ProductController : Controller
    {
        private static readonly List<Product> Products = new List<Product>() {
            new Product(){Id = 1, Category = "Toy", Name = "Product 1", Price = 10000},
            new Product(){Id = 2, Category = "Phone", Name = "Product 2", Price = 20000},
            new Product(){Id = 3, Category = "Electric device", Name = "Product 3", Price = 103000},
            new Product(){Id = 4, Category = "Fashion", Name = "Product 4", Price = 100040},
            new Product(){Id = 5, Category = "Food", Name = "Product 5", Price = 50000},
            new Product(){Id = 6, Category = "Vegetable", Name = "Product 6", Price = 14000},
            new Product(){Id = 7, Category = "Comics", Name = "Product 7", Price = 21000},
            new Product(){Id = 8, Category = "Games", Name = "Product 8", Price = 56000},
            new Product(){Id = 9, Category = "Animals", Name = "Product 9", Price = 121000},
            new Product(){Id = 10, Category = "Furnitures", Name = "Product 10", Price = 1130000},
        };

        [HttpGet]
        public ActionResult GetAllProducts()
        {
            try
            {
                return Ok(Products);
            }
            catch (Exception)
            {
                return BadRequest();
            }
        }

        [HttpPost("AddProduct")]
        public ActionResult<string> AddProduct(Product product)
        {
            try
            {
                Products.Add(product);
                return Ok(Products);
            }
            catch (Exception)
            {
                return BadRequest();
            }
        }
    }
}
