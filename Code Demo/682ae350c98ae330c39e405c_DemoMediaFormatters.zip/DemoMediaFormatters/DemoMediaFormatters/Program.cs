using DemoMediaFormatters.Formatter;
using Microsoft.AspNetCore.Mvc.Formatters;
using Microsoft.Extensions.Options;
using System.Xml.Serialization;

namespace DemoMediaFormatters {

    public class Program {

        public static void Main(string[] args) {


            var builder = WebApplication.CreateBuilder(args);

            // Add services to the container.

            builder.Services.AddControllers(
                options => {
                options.OutputFormatters.Add(new CsvOutputFormatter());
                //options.OutputFormatters.Clear();
                options.OutputFormatters.Add(new XmlSerializerOutputFormatter());
                ////options.OutputFormatters.RemoveType<SystemTextJsonOutputFormatter>();
                options.InputFormatters.Add(new XmlSerializerInputFormatter(options));
                options.InputFormatters.Add(new CsvInputFormatter());
            }
            );

            // Learn more about configuring Swagger/OpenAPI at https://aka.ms/aspnetcore/swashbuckle
            builder.Services.AddSwaggerGen();

            // Create a new instance of HttpConfiguration


            var app = builder.Build();

            // Configure the HTTP request pipeline.
            if (app.Environment.IsDevelopment()) {
                app.UseSwagger();
                app.UseSwaggerUI();
            }

            app.MapControllers();

            app.Run();
        }
    }
}