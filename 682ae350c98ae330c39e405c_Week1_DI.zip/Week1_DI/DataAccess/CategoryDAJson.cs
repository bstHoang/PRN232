﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Week1_DI.Models;

namespace Week1_DI.DataAccess
{
    internal class CategoryDAJson : ICategoryDA
    {
        public List<Category> GetCategories()
        {
            //doc 1 file json -> data
            return null;
        }
    }
}
